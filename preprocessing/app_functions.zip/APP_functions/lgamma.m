function [outputArg1] = lgamma(inputArg1)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = gammaln(inputArg1);

end

