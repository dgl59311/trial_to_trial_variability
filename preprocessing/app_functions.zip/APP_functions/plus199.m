function [ output ] = plus199( input )
%PLUS199 is for the specific case that the number of trials 
%       are more than 100. Thus passing the 199 limit in our
%       lab standard
%   input - is a vector with the trial number
%   output - is a vector with the trial numbers after changing 
%           to continue more than 199

    output = input;
    if find(input == 199) == length(input)
    
    elseif (find(input == 199)+1) ~= 200
        for i=1:length(input)-100
            output(find(input == 199)+i) = output(find(input == 199)+i)+100;
        end
    else 
    end

end

