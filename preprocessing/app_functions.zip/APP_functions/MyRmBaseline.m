function [ outsignal ] = MyRmBaseline( EEG, time )
% This function removes the baseline of EEG data
% EEG - input in EEGlab format
% time - the window to remove baseline

% if isempty(signal) | isempty(Fs) | isempty time
%     error('all fields should be complete');
% end
signal = EEG.data;
pnts = EEG.pnts;
Fs = EEG.srate;

if isempty(signal)
    error('No signal present.');
elseif isempty(pnts)
    error('No number of points.');
elseif isempty(Fs)
    error('No sampling frequency info');
elseif isempty(time)
    error('No time reference for baseline removal');
end

t1 = time(1);
t2 = time(2);
t = (t1:1/Fs:t2-1/Fs);
[mv,s1]=min(abs(t-t1));
[mv,s2]=min(abs(t-t2));

if length(size(signal)) == 2
    mean_val = mean(signal(:,[s1:s2]),2);
    out = signal - repmat(mean_val,1,pnts);
elseif length (size(signal)) == 3
    mean_val = mean(signal(:,[s1:s2],:),2);
    out = signal - repmat(mean_val,[1,pnts,1]);
else
    error ('data size not supported');
end

    EEG.data = out;
    outsignal = EEG;
end

